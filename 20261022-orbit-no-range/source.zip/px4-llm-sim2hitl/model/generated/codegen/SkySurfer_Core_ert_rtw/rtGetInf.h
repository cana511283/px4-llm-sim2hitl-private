/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: rtGetInf.h
 *
 * Code generated for Simulink model 'SkySurfer_Core'.
 *
 * Model version                  : 14.12
 * Simulink Coder version         : 26.2 (R2026b) 22-May-2026
 * C/C++ source code generated on : Tue Oct 20 02:47:22 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef rtGetInf_h_
#define rtGetInf_h_
#include "rt_nonfinite.h"

extern double rtGetInf(void);
extern float rtGetInfF(void);
extern double rtGetMinusInf(void);
extern float rtGetMinusInfF(void);

#endif                                 /* rtGetInf_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
